import React, { useState } from "react";
import { View, Text, Image, ScrollView, StyleSheet, TextInput, TouchableOpacity } from "react-native";

const products = [
  { name: "Tractors", image: require("./assets/tractors.jpg") },
  { name: "Harrows", image: require("./assets/harrows.jpg") },
  { name: "Seeders/Planters", image: require("./assets/seeders.jpg") },
  { name: "Fertilizer Spreaders", image: require("./assets/fertilizer-spreader.jpg") },
  { name: "Irrigation Systems", image: require("./assets/irrigation.jpg") },
  { name: "Combine Harvesters", image: require("./assets/combine-harvesters.jpg") },
  { name: "Plows", image: require("./assets/plows.jpg") },
  { name: "Sprayers", image: require("./assets/sprayers.jpg") },
  { name: "Cultivators", image: require("./assets/cultivators.jpg") },
  { name: "Threshers", image: require("./assets/threshers.jpg") },
];

export default function ProductSection() {
  const [search, setSearch] = useState("");

  // Filter products based on search input
  const filteredProducts = products.filter((product) =>
    product.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.header}>Agricultural Products</Text>

      {/* Search Bar */}
      <TextInput
        style={styles.searchBar}
        placeholder="Search products..."
        value={search}
        onChangeText={(text) => setSearch(text)}
      />

      {/* Product Grid */}
      <View style={styles.grid}>
        {filteredProducts.map((product, index) => (
          <View key={index} style={styles.card}>
            <Image source={product.image} style={styles.image} />
            <Text style={styles.text}>{product.name}</Text>
          </View>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
    backgroundColor: "#f5f5f5",
  },
  header: {
    fontSize: 24,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 10,
  },
  searchBar: {
    backgroundColor: "white",
    padding: 10,
    borderRadius: 10,
    fontSize: 16,
    marginBottom: 15,
    borderColor: "#ccc",
    borderWidth: 1,
  },
  grid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },
  card: {
    backgroundColor: "white",
    padding: 10,
    borderRadius: 10,
    alignItems: "center",
    width: "48%",
    marginBottom: 10,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  image: {
    width: 100,
    height: 100,
    resizeMode: "cover",
    borderRadius: 10,
  },
  text: {
    marginTop: 5,
    fontSize: 16,
    fontWeight: "bold",
  },
});
